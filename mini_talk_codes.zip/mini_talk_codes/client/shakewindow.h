#ifndef SHAKEWINDOW_H
#define SHAKEWINDOW_H

#include <QObject>
#include <QtGui>
#include <QTimer>

//枚举最大振动次数为15
enum {MaxLimitTime=15};
//枚举最大振动幅度为10
enum {MaxLimitSpace=10};
//抖动定时器的时间间隔
enum {ShakeTime=20};

class ShakeWindow : public QObject
{
    Q_OBJECT

public:
    explicit ShakeWindow(QDialog *cdia,QObject *parent = nullptr);
    //开始振动函数
    void startShake();

private:
    //所有的都加上c，意为client端
    QDialog *cdia;
    //计时器对象
    QTimer *cTimer;
    //定义一个位置int
    int cposition;
    //光标位置
    QPoint curPos;

signals:

public slots:
    void slotTimeOut();

};

#endif // SHAKEWINDOW_H

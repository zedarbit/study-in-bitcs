﻿#include "ClientSql.h"

#pragma execution_character_set("utf-8")
MySql::~MySql()
{
    delete query;
}

void MySql::initsql()
{

    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("sqlite/CLIENT.db");
    if (db.open())
    {
        qDebug() << "Database connected successfully!";
        createtable();
        return;
    }
    else
    {
        qDebug() << "Database connected failed!";
        return;
    }
}
/**
 * @brief MySql::createtable创建用户信息表，聊天信息表
 */
void MySql::createtable()
{
    query = new QSqlQuery;

    query->exec("create table userInfo(name VARCHAR(30)  NOT NULL,password VARCHAR(30) NOT NULL)");
    query->exec("create table chatInfo(username VARCHAR(30)  NOT NULL,receiver VARCHAR(30) NOT NULL,currentFileName VARCHAR(100) NOT NULL,byteWritten VARCHAR(30),totalBytes VARCHAR(30))");
}
/**
 * @brief MySql::insertUser在数据库中插入用户名，密码
 * @param name
 * @param password
 */
void MySql::insertUserInfo(QString name,QString password)
{
    QString strcheck = QString("insert into userInfo values('%1','%2')").arg(name).arg(password);
    query = new QSqlQuery;
    if (!query->exec(strcheck))
    {
        qDebug() << query->lastError();
        return;
    }
}
/**
 * @brief MySql::readUser在userInfo中检索用户信息
 * @return
 */
QString MySql::readUser()
{
    QString strcheck = QString("select name from userInfo");
    query = new QSqlQuery;
    if (!query->exec(strcheck))
    {
        qDebug() << query->lastError();
        return "";
    }

    while (query->next())
    {
        return query->value(0).toString();
    }
}


/**
 * @brief MySql::deleteUserInfo删减用户信息
 */
void MySql::deleteUserInfo()
{
    QString strdelete = QString("delete from userInfo");
    query = new QSqlQuery;
    if (!query->exec(strdelete))
    {
        qDebug() << query->lastError();
        return;
    }
}

/**
 * @brief MySql::insertChatFileInfo
 * @param username
 * @param receiver
 * @param currentFileName
 * @param byteWritten
 * @param totalBytes
 */
void MySql::insertChatFileInfo(QString username, QString receiver, QString currentFileName, QString byteWritten, QString totalBytes)
{
        query = new QSqlQuery;
        QString strFind = QString("select * from chatInfo where username='%1' and currentFileName='%2' and receiver = '%3'")
                         .arg(username).arg(currentFileName).arg(receiver);
        if (query->exec(strFind))
        {
            if (query->next())
            {
                QString strUpdate = QString("update chatInfo set byteWritten ='%1'and totalBytes ='%2' where username ='%3' and currentFileName='%4' and receiver = '%5'")
                    .arg(byteWritten).arg(totalBytes).arg(username).arg(currentFileName).arg(receiver);
                bool result = query->exec(strUpdate);
                if (result)
                {
                    return;
                }
            }
            else {
                QString strInsert = QString("insert into chatInfo values('%1','%2','%3','%4','%5')")
                    .arg(username).arg(receiver).arg(currentFileName).arg(byteWritten).arg(totalBytes);
                bool result = query->exec(strInsert);
                if (result)
                {
                    return;
                }
            }
        }
        return;
}

QStringList MySql::selectChatFileInfo(QString filename,QString strUserName, QString receiver)
{
    QStringList strList;
    QString strselect = QString("select * from chatInfo where currentFileName = '%1' and username = '%2' and receiver ='%3'")
        .arg(filename).arg(strUserName).arg(receiver);
    query = new QSqlQuery;
    if (!query->exec(strselect))
    {
        qDebug() << query->lastError();
        return strList;
    }

    while (query->next())
    {
        strList.append(query->value("currentFileName").toString());
        strList.append(query->value("byteWritten").toString());
        strList.append(query->value("totalBytes").toString());
    }

    return strList;
}



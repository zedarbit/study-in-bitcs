﻿#include "clientLogin.h"
#include "ui_login.h"



#pragma execution_character_set("utf-8")
Login::Login(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Login)
{
    ui->setupUi(this);
    this->setWindowTitle("登录");
    ui->qle_ip->setFocus();
    ui->qle_ip->setText("");
    ui->qle_port->setText("1234");
    ui->label_result->setStyleSheet("color:red;");
    ui->label_result->setWordWrap(true);
    ui->label_result->setAlignment(Qt::AlignTop);
    //ui->qle_password->setEchoMode(QLineEdit::Password);

    ui->checkBox->setCheckState(Qt::Unchecked);
    QMetaObject::connectSlotsByName(ui->pb_login);
    QMetaObject::connectSlotsByName(ui->pb_register);
    mSocketUtil = new SocketUtil(this);
    mTcpSocket = new QTcpSocket();
    init();



}

//socket的关闭
Login::~Login()
{
    mTcpSocket->close();
    mTcpSocket->deleteLater();
    mTcpSocket->disconnectFromHost();
    mTcpSocket = nullptr;
}

void Login::init()//初始化
{
    //绑定socket错误
    connect(mTcpSocket, SIGNAL(error(QAbstractSocket::SocketError)),this, SLOT(displaySocketError(QAbstractSocket::SocketError)));

    //绑定接受
    connect(mTcpSocket, SIGNAL(readyRead()), this, SLOT(readMessages()));
}

void Login::on_pb_login_clicked()//点击登录按钮
{
    if ("" == ui->qle_ip->text() || "" == ui->qle_port->text())
    {
        QMessageBox::information(this, "警告", "ip或端口号为空!", QMessageBox::Ok);
        return;
    }
    connectSocket();//发送连接服务器请求

    QString strUserName = ui->qle_username->text();
    QString strPassword = ui->qle_password->text();
    if ( "" == strUserName || "" == strPassword)
    {
        QMessageBox::information(this, "警告", "输入不能为空", QMessageBox::Ok);
        return;
    }

    QString strModuleName = "login";
    QString strSendData = strModuleName + "#" + strUserName + "#" + strPassword;
    mSocketUtil->writeData(mTcpSocket, strSendData.toLatin1());
}

//注册部分

//成功回调
void Login::Success(QString message)
{
    ui->label_result->setText(ui->label_result->text() + message + "\n");
}

//失败
void Login::Fail(QString message)
{
    ui->label_result->setText(ui->label_result->text() + message + "\n");
}

void Login::on_pb_register_clicked()//点击注册按钮
{
    //获取IP和端口
    QString strIp = ui->qle_ip->text();
    QString strPort = ui->qle_port->text();
    mSocketUtil->WriteIni(strIp, strPort);//将数据写入配置文件
    mRegister= new Register(NULL, mTcpSocket, mSocketUtil);
    mRegister->setModal(true);
    mRegister->exec();
}


void Login::connectSocket()//把ip和端口port写到配置文件Ini里
{
    //获取IP和端口号
    QString strIp = ui->qle_ip->text();

    QString strPort = ui->qle_port->text();
    mSocketUtil->WriteIni(strIp, strPort);
    mSocketUtil->connect(mTcpSocket);//connect被封装于处理类socketutil里
}

//服务端返回消息
void Login::readMessages()
{
    QString strRevData = mTcpSocket->readAll();
    QStringList strlRevlist = strRevData.split("#");
    if ("login" == strlRevlist[0] && "true" == strlRevlist[3])
    {
        MySql mysql;
        mysql.initsql();
        mysql.deleteUserInfo();
        mysql.insertUserInfo(strlRevlist[1], strlRevlist[2]);
        //更新用户信息
        mOnlineUserlist = new OnlineUserlist(NULL, mTcpSocket, mSocketUtil);
        mOnlineUserlist->show();
        this->close();
    }
    else if ("login" == strlRevlist[0] && "false" == strlRevlist[3])
    {
        QMessageBox::information(this, "信息提示", "登录失败，用户名或密码错误", QMessageBox::Ok);
    }
    else if ("nouser" == strlRevlist[0] && "false" == strlRevlist[3])
    {
        QMessageBox::information(this, "信息提示", "还未注册,请先注册", QMessageBox::Ok);
    }
}


void Login::displaySocketError(QAbstractSocket::SocketError)
{
    ui->label_result->setText(ui->label_result->text() + mTcpSocket->errorString() + "\n");
}


void Login::on_checkBox_stateChanged(int arg1)//控件-密码可视与隐藏
{
    if(arg1==0) ui->qle_password->setEchoMode(QLineEdit::Password);

    else ui->qle_password->setEchoMode(QLineEdit::Normal);
}

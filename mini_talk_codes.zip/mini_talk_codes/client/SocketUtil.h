﻿#pragma once
#ifndef SocketController_H
#define SocketController_H
#include <QtNetwork/QtNetwork>
#include <QString>
#include "socketparent.h"
#include "qdebug.h"
//socket封装类，包含连接、初始化、数据传输等功能
class SocketUtil
{
public:
    SocketUtil(socketparent* socketSink)
    {
        this->mSock = socketSink;
        sip = "";
        sArgPort = "";
    }
public:
    void connect(QTcpSocket* socket);

    void WriteIni(const QString &ip, const QString &port);//保存ip和端口信息帮助基础功能的实现
    void ReadIni();
    void writeData(QTcpSocket* socket, const char* data);
    static void delayMSec(unsigned int msec);

private:
    socketparent* mSock;
    QString sip;
    QString sArgPort;
    SocketUtil* mSocket;
};
#endif

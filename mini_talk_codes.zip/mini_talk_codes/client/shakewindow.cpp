#include "shakewindow.h"
#include <QObject>
#include <QDesktopWidget>
#include <QPoint>
#include <QtGui>
#include <QDialog>

//头文件内容：
//所有的都加上c，意为client端
//QDialog *cdia;
//计时器对象
//QTimer *cTimer;
//抖动次数int
//int cposition;
//光标、对话框？位置
//QPoint curPos;
//开始振动函数
//void startShake();
//槽函数
//void slotTimeOut();

//0901-抖一抖功能实现

ShakeWindow::ShakeWindow(QDialog *cdia, QObject *parent) : QObject(parent)
{
    //实例化
    this->cdia = cdia;
    //都是timer类
    cTimer=new QTimer(this);
    QObject::connect(cTimer,SIGNAL(timeout()),this,SLOT(slotTimeOut()));
    cposition=MaxLimitTime;
}

void ShakeWindow::startShake(){
    //如果正在抖动就返回，不进行其他操作
    if(cposition<MaxLimitTime) return;
    cposition=1;
    //获取光标、对话框？位置
    curPos=this->cdia->pos();
    //定时器开始计时
    cTimer->start(ShakeTime);
    //else
}

void ShakeWindow::slotTimeOut(){
    //如果没抖动完毕
    if(cposition<MaxLimitTime){
        ++cposition;
        //switch(cposition%2){
            if(cposition%2==1)
                //case 1:
            {
                //计算下一步要去的位置
                QPoint targetPos(curPos.x()-MaxLimitSpace,curPos.y());
                //设置下一步要去的位置
                this->cdia->move(targetPos);
            }
            else if(cposition%2==0)
                    //case 0:
            {
                //计算下一步要去的位置
                QPoint targetPos(curPos.x(),curPos.y());
                //设置下一步要去的位置
                this->cdia->move(targetPos);
            }

        }
    //否则抖动完毕，关闭计时器
    else cTimer->stop();
}


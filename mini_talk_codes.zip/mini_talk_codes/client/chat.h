﻿#ifndef CHAT_H
#define CHAT_H

#include <QtWidgets/QWidget>
#include <QtNetwork/QtNetwork>
#include <QDialog>
#include <QTextBrowser>
#include "ui_chat.h"
#include "socketparent.h"
#include "SocketUtil.h"
#include <windows.h>
#include <commdlg.h>
#include <QFile>
#include <QCloseEvent>
#include <ClientSql.h>
#include <QDebug>
#include "shakewindow.h"


namespace Ui {
class Chat;
}

class Chat: public QDialog, public socketparent
{
    Q_OBJECT

public:

    Chat(QTcpSocket *pTcpSocket,SocketUtil *mSocketUtil = 0, QVariant value = "");
    ~Chat();
    void Success(QString message);
    void Fail(QString message);
    void init();
    QVariant value;
    void showMessage(QString str);

    //发送文件
    void string_replace(std::string & strBig, const std::string & strsrc, const std::string & strdst);
    std::string GetPathOrURLShortName(std::string strFullName);
    QString getCurrentTime();
    void updateServerProgress(const QByteArray&,const qint64 &);
protected:
    void closeEvent(QCloseEvent *event);
    bool eventFilter(QObject *object,QEvent *event);
private:
    Ui::Chat ui;
    QTcpSocket *mTcpSocket;//消息通讯的socket
    QTcpSocket *mSocket;//文件传输socket
    SocketUtil *mSocketUtil;
    QTextBrowser *textBrowser;
    //shakeWindow 类型的名叫shakeEff的变量
    ShakeWindow shakeEff;

    //发送文件
    QString fileName;
    TCHAR szFile[MAX_PATH];
    //设置变量
    qint64 totalBytes;
    qint64 total;
    qint64 Hsize;
    qint64 bytestoWrite;
    qint64 byteWritten;

    qint64 perDataSize;//数据大小
    QFile *localFile;
    QByteArray inBlock;
    QByteArray outBlock;
    MySql mysql;
    qint64 FileSize;
    qint64 FileRemainderSize;
    qint64 FileSendSize;

    //接收文件
    qint64 bytesReceived;  //数据大小
    qint64 fileNameSize;  //文件名大小
    qint64 revtTotalBytes;

    qint64 sendAndRecLen;

    QString currentFileName;
signals:
    void closechat(QString);

private slots:
    void sendMessage();
    void displaySocketError(QAbstractSocket::SocketError);
    void resive();

    //发送文件部分
    void openFile();
    void sendFile();
    //更新进度
    void updateClientProgress(qint64);
    void stopFile();
    void resendFile();
    void updateResendProgress(qint64 numBytes);
    void selectHistoryChatMessage();

};
#endif

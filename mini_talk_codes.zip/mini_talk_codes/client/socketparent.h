﻿#pragma once
#ifndef  ISOCKETSINK_H
#define  ISOCKETSINK_H
#include <QString>
using std::string;
//设置父类，方便socket操作的信息回调
class socketparent
{
public:
    socketparent() {};
    virtual ~socketparent() {};
public:
    virtual void Success(QString message) = 0;
    virtual void Fail(QString message) = 0;
};
#endif



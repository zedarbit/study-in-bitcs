﻿#include "Register.h"
#include<QSound>

RegisterControl::RegisterControl()
{

}

bool RegisterControl::registerUser(int &status, QString &message, const QString &sockedID, const QStringList &list)
{
    QString qstrSendData = list[0];
    MySql mysql;
    mysql.registerUser(list[1], list[2], status, message);
    if (status == 1) {
        qstrSendData += "#" + list[1] + "#" + message + "#true";
        message = qstrSendData;
        //注册成功提示音
        //QSound::play("C:\\Windows\\media\\Windows Foreground.wav");
        QSound* bell_rig =new QSound("C:\\Windows\\media\\Alarm08.wav");
        bell_rig->play();
        return true;
    }
    else {
        qstrSendData += "#" + list[1] + "#" + message + "#false";
        message = qstrSendData;
        //注册失败提示音
        QSound::play("C:\\Windows\\media\\Windows Error.wav");
        return false;
    }
}

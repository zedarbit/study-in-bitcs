﻿#ifndef LOGINCONTROL_H
#define LOGINCONTROL_H

#include<QString>
#include<QStringList>
#include"ServerSql.h"

class logincontrol
{
public:
    logincontrol();
    static bool login(int&,QString&, const QString&, const QStringList&);
    static void logOut(const QString&);
    static void loginStatusChange(const QString&, const QString&);
    static void closeServer();
};

#endif // LOGINCONTROL_H

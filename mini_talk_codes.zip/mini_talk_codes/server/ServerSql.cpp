﻿#include "ServerSql.h"

#pragma execution_character_set("utf-8")
MySql::~MySql()
{
    delete query;
}

//初始化数据库
void MySql::initSql()
{
    //加载数据库
    qDebug()<<QSqlDatabase::drivers();
    //加载驱动，使用sqlite数据库
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("sqlite/SERVER.db");
    if (db.open())
    {   //如果成功打开，
        qDebug() << "Database connected successfully!";
        createTable();
        return;
    }
    else
    {   //打开失败，回退
        qDebug() << "Database connected failed!";
        qFatal("failed to connect database.");
        return;
    }
}

/**
 * @brief MySql::createTable
 * 创建用户状态表，聊天记录表
 */
void MySql::createTable()
{
    query = new QSqlQuery;
    query->exec("create table userStatus(name VARCHAR(30)  NOT NULL,password VARCHAR(30) NOT NULL,isLogin VARCHAR(1),socketID VARCHAR(20))");
    query->exec("create table chatHistory(id INTEGER PRIMARY KEY AUTOINCREMENT,pointA varchar(30)  NOT NULL,pointB varchar(30) NOT NULL,content TEXT(5000),time varchar(50) NOT NULL)");
    //query->exec("create table sendingfile(fromA VARCHAR(30)  NOT NULL,fileName VARCHAR(150),fileTotalLength VARCHAR(20),hasReceiveLength VARCHAR(20))");
}

/**
 * @brief MySql::loginUser检索用户登录状态
 * @param name
 * @param passWard
 * @param socketID
 * @param status
 * @param message
 * @return
 */
bool MySql::loginUser(const QString name, const QString passWord, const QString socketID, int &status, QString &message)
{
    QString strCheck = QString("select * from userStatus where name='%1' and password='%2'").arg(name).arg(passWord);
    query = new QSqlQuery;
    if (!query->exec(strCheck))
    {
        qDebug() << query->lastError();
        return false;
    }
    if (!query->next())
    {//如果没有查到数据，说明信息错误
        status = 0;
        message = "wrong username or password";
        return false;
    }
    //获取islogin的数据转成0或1，判断是否已经登陆
    int isLogin = query->value("isLogin").toInt();
    if (isLogin)
    {
        //已经登录，不能重复登录
        status = 0;
        message = "repeat login";//重复登录
        return false;
    }
    QString strlogin = QString("update userStatus set isLogin ='%1' , socketID ='%2' where name ='%3'").arg("1").arg(socketID).arg(name);
    bool ret = query->exec(strlogin);
    if (ret)
    {
        status = 1;
        message = "login success";//登录成功;
        return true;
    }
    return false;
}
/**
 * @brief MySql::registerUser用户注册，避免重复注册
 * @param name
 * @param passWard
 * @param status
 * @param message
 * @return
 */
bool MySql::registerUser(const QString name, const QString passWard, int &status, QString &message)
{
    QString strreg = QString("select * from userStatus where name='%1'").arg(name);
    query = new QSqlQuery;
    if (!query->exec(strreg))
    {
        qDebug() << query->lastError();
        return false;
    }
    if (query->next())
    {
        status = 0;
        message = "username exists";
        return false;
    }
    strreg = QString("insert into userStatus values('%1','%2','%3','%4')").arg(name).arg(passWard).arg(0).arg(" ");
    bool ret = query->exec(strreg);
    if (ret)
    {
        status = 1;
        message = "register success";
        return true;
    }
    return false;
}

bool MySql::loginStatusChange(QString userName, QString socketID)
{
    QString strsc = QString("update userStatus set  socketID ='%1' where name ='%2'").arg(socketID).arg(userName);
    query = new QSqlQuery;
    bool result = query->exec(strsc);
    if (result)
    {
        return true;
    }
    return false;
}

bool MySql::logOut(QString socketID)
{
    QString strsOut = QString("select * from userStatus where socketID='%1'").arg(socketID);
    query = new QSqlQuery;
    if (query->exec(strsOut))
    {
        if (query->next())
        {
            QString strsOut = QString("update userStatus set isLogin ='%1', socketID ='%2' where socketID ='%3'").arg("0").arg("0").arg(socketID);
            bool result=query->exec(strsOut);
            if (result)
            {
                return true;
            }
        }
    }
    return false;
}
//关闭服务，所有人下线
bool MySql::closeServer()
{
    QString strsOut = QString("select * from userStatus");
    query = new QSqlQuery;
    if (query->exec(strsOut))
    {
        while (query->next())
        {
            QString strsOut = QString("update userStatus set isLogin ='%1', socketID ='%2'").arg("0").arg("0");
            query->exec(strsOut);
        }
        return true;
    }
    return false;
}




/**
 * @brief MySql::insertChatRecord写入聊天的发送者，接受者，内容，时间
 * @param sender
 * @param receiver
 * @param content
 * @param time
 * @return
 */
bool MySql::insertChatRecord(const QString & sender, const QString & receiver, const QString & content, const QString & time)
{
    query = new QSqlQuery;
    QString strInsert = QString("insert into chatHistory values(null,'%1','%2','%3','%4')").arg(sender).arg(receiver).arg(content).arg(time);
    bool result = query->exec(QString::fromLocal8Bit(strInsert.toLocal8Bit()));
    if (result)
    {
        qDebug() << u8"插入聊天记录:" << strInsert;
        return true;
    }
    return false;
}

/**
 * @brief MySql::selectChatRecord服务器查询聊天记录，返回历史信息
 * @param sender
 * @param receiver
 * @param result
 * @return
 */
bool MySql::selectChatRecord(const QString & sender, const QString & receiver, QString &result)
{
    QString strChat = QString("select * from chatHistory where (pointA='%1' and pointB='%2') or (pointA='%3' and pointB='%4') order by id")
                            .arg(sender).arg(receiver).arg(receiver).arg(sender);
    query = new QSqlQuery;
    if (!query->exec(strChat))
    {
        qDebug() << query->lastError();
        return false;
    }
    QString resultData = "record##";
    while (query->next()) {
        QString senderString = query->value(1).toString();
        QString receiverString = query->value(2).toString();
        QString contentString = query->value(3).toString();
        QString timeString = query->value(4).toString();
        result = result + resultData;
        result += senderString + "##";
        result += receiverString + "##";
        result += contentString + "##";
        result += timeString + "##";
    }
    qDebug() << u8"服务返回聊天记录:" << result;
    return true;
}
